from torch.utils.data import Dataset

class TaskData(Dataset):
    def __init__(self, task, split = "train"):
        super().__init__()
        self.data = task[split]['img'] if 'img' in task[split].features else task[split]['image']
        self.task = task
        self.label_key = task[split][task['label_key']]

    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        image = self.data[idx]
        return image, self.label_key[idx]
